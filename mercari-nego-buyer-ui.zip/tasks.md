# Tasks: メルカリNego v0.3

## Spec
- [x] T001 spec.md v0.3 — 종결 불변식 · 상품 유지 · 取引チャット
- [x] T002 plan.md

## Function
- [x] T003 [FR-004] generateRounds 마지막 쌍 = settle — `demo/protocol.js` + test
- [x] T004 [FR-013] 取消/決裂/成立에서 상품 chrome 유지 — `demo/app.js`

## UI
- [x] T005 [FR-006/012] 출시 수준 メルカリ 스킨 — `demo/index.html`

## Verify
- [ ] T006 `node demo/protocol.test.mjs`
- [ ] T007 Browser: 成立 3면, 不成立 3면, 取消 후에도 사진
