# Implementation Plan: メルカリNego v0.3

**Spec**: `specs/004-mercari-nego/spec.md`

## Summary

가격 모순과 빈 결과 화면을 없앤다. 마지막 공개 제시 = settle. 폰은 상품을 버리지 않는다. 가운데는 取引チャット.

## Design

- `generateRounds`: 중간 양보는 성격대로. **항상 마지막에 buyer=settle, seller=settle** 한 쌍을 붙인다. 헤더 현재가도 settle.
- 取消/決裂/成立: `renderSeller`/`renderBuyer`는 `itemChrome`을 유지하고 お知らせ만 교체. `.wait` 원 화면 삭제.
- Live: 상품 스트립(썸네일+제목+表示価格) + 버블 + 하단 成立/不成立 바. ウリ/カイ는 32px 아바타만.

## Requirement mapping

| Req | Design | Verify |
|---|---|---|
| FR-003/004 | protocol last pair = settle | `node demo/protocol.test.mjs` — 램프 마지막 4500/4500 |
| FR-011/013 | 전 종료가 상품 위 お知らせ | 브라우저: 取消 후에도 사진 보임 |
| FR-006/012 | 取引チャット + メルカリ 상품면 | 램프 成立 3면, 헤드폰 gap 3면 |

## Alternatives

| Decision | Choice | Rejected |
|---|---|---|
| 성사 표시 | 마지막 버블 = settle | 중간 제시를 성사로 읽게 둠 |
| 결과면 | 상품 + お知らせ | 흰 바탕 売/買 원 |
