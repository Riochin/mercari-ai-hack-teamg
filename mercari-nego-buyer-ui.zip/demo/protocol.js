/**
 * Deterministic A2A price protocol for メルカリNego.
 * Numbers only. Copy/templates live in the UI layer.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.NegoProtocol = factory();
})(typeof self !== "undefined" ? self : this, function () {
  const CONCESSION = 0.75;

  var NATURES = {
    gentle: { id: "gentle", ja: "おだやか", hint: "すぐ寄る", concession: 0.9 },
    hardy: { id: "hardy", ja: "がんばりや", hint: "ふつう", concession: 0.75 },
    adamant: { id: "adamant", ja: "いじっぱり", hint: "粘る", concession: 0.4 },
  };

  function natureOf(id) {
    return NATURES[id] || NATURES.hardy;
  }

  function concessionOf(id) {
    return natureOf(id).concession;
  }

  function parseRates(opts) {
    var buyerRate = CONCESSION;
    var sellerRate = CONCESSION;
    var buyerNature = "hardy";
    var sellerNature = "hardy";
    if (typeof opts === "number") {
      buyerRate = sellerRate = opts;
    } else if (opts && typeof opts === "object") {
      if (opts.buyer) {
        buyerNature = opts.buyer;
        buyerRate = concessionOf(opts.buyer);
      }
      if (opts.seller) {
        sellerNature = opts.seller;
        sellerRate = concessionOf(opts.seller);
      }
      if (opts.concession != null) buyerRate = sellerRate = opts.concession;
    }
    return { buyerRate: buyerRate, sellerRate: sellerRate, buyerNature: buyerNature, sellerNature: sellerNature };
  }

  function round100(n) {
    return Math.round(n / 100) * 100;
  }

  function settlePrice(floor, cap) {
    if (cap < floor) return null;
    return round100((floor + cap) / 2);
  }

  function gapAmount(floor, cap) {
    return cap >= floor ? 0 : floor - cap;
  }

  function startBids(ask, cap, median) {
    return {
      buyer: Math.min(cap, round100(median * 0.85)),
      seller: Math.min(ask, round100(median * 1.08)),
    };
  }

  function vsMedianPct(settle, median) {
    if (!median) return null;
    var raw = ((settle - median) / median) * 100;
    var sign = raw < 0 ? -1 : 1;
    return (sign * Math.round(Math.abs(raw) * 10)) / 10;
  }

  function floorHint(floor, median) {
    if (floor <= median) return "high";
    if (floor <= median * 1.15) return "mid";
    return "low";
  }

  function capIsUnrealistic(cap, median) {
    return cap < median * 0.85;
  }

  function neededCap(floor) {
    return floor;
  }

  var EVIDENCE_ORDER = ["days", "condition", "sold", "shipping"];

  function bindEvidence(item, key) {
    if (!item) return null;
    if (key === "sold" && (item.soldCount || 0) < 3) return null;
    if (key === "days" && item.days == null) return null;
    if (key === "condition" && !item.condition) return null;
    if (key === "shipping" && !item.shipping) return null;

    if (key === "sold") {
      return {
        key: "sold",
        label: "SOLD",
        title: "直近の成約",
        body:
          "中央値 ¥" +
          item.median.toLocaleString("ja-JP") +
          " · " +
          item.soldCount +
          "件",
      };
    }
    if (key === "days") {
      return {
        key: "days",
        label: "出品",
        title: "出品 " + item.days + "日",
        body: item.viewsTrend === "down" ? "閲覧は減少傾向" : "閲覧は安定",
      };
    }
    if (key === "condition") {
      return {
        key: "condition",
        label: "状態",
        title: "状態 " + item.condition,
        body: item.extras || "状態の根拠のみ",
      };
    }
    if (key === "shipping") {
      return {
        key: "shipping",
        label: "配送",
        title: item.shipping,
        body: "価格に配送条件を織り込み",
      };
    }
    if (key === "close") {
      return {
        key: "close",
        label: "成立",
        title: "中点",
        body: "成立価格",
      };
    }
    return null;
  }

  function generateRounds(item, floor, cap, concession) {
    var rates = parseRates(concession);
    var settle = settlePrice(floor, cap);
    if (settle == null) {
      var failedStarts = startBids(item.ask, cap, item.median);
      var failedRounds = [
        { side: "buyer", price: failedStarts.buyer, evidence: bindEvidence(item, "days") },
        { side: "seller", price: failedStarts.seller, evidence: bindEvidence(item, "condition") },
      ];
      if (failedStarts.buyer !== cap) {
        failedRounds.push({ side: "buyer", price: cap, evidence: bindEvidence(item, "sold") });
      }
      if (failedStarts.seller !== floor) {
        failedRounds.push({ side: "seller", price: floor, evidence: bindEvidence(item, "shipping") });
      }
      return {
        ok: false,
        settle: null,
        gap: gapAmount(floor, cap),
        rounds: failedRounds,
        vsMedian: null,
        natures: { buyer: rates.buyerNature, seller: rates.sellerNature },
      };
    }

    var starts = startBids(item.ask, cap, item.median);
    var buyer = starts.buyer;
    var seller = starts.seller;
    var rounds = [];
    var thinComps = (item.soldCount || 0) < 3;

    function push(side, price, evidenceKey) {
      rounds.push({
        side: side,
        price: price,
        evidence: thinComps && evidenceKey === "sold" ? null : bindEvidence(item, evidenceKey),
      });
    }

    push("buyer", buyer, EVIDENCE_ORDER[0]);
    push("seller", seller, EVIDENCE_ORDER[1]);

    buyer = round100(buyer + rates.buyerRate * (settle - buyer));
    push("buyer", buyer, EVIDENCE_ORDER[2]);

    seller = round100(seller - rates.sellerRate * (seller - settle));
    push("seller", seller, EVIDENCE_ORDER[3]);

    if (rates.buyerRate <= 0.5 || rates.sellerRate <= 0.5) {
      buyer = round100(buyer + rates.buyerRate * (settle - buyer));
      push("buyer", buyer, "sold");
      seller = round100(seller - rates.sellerRate * (seller - settle));
      push("seller", seller, "shipping");
    }

    // Closing invariant: last public bids == settle (natures only change mid rounds).
    push("buyer", settle, "close");
    push("seller", settle, "close");

    return {
      ok: true,
      settle: settle,
      gap: 0,
      rounds: rounds,
      vsMedian: vsMedianPct(settle, item.median),
      natures: { buyer: rates.buyerNature, seller: rates.sellerNature },
    };
  }

  function publicLog(result, extra) {
    extra = extra || {};
    var rows = (result.rounds || []).map(function (r, i) {
      return {
        n: i + 1,
        side: r.side,
        price: r.price,
        evidence: r.evidence
          ? { title: r.evidence.title, body: r.evidence.body, key: r.evidence.key }
          : null,
      };
    });
    var verdict = {
      kind: extra.kind || (result.ok ? "settled" : "gap"),
      settle: result.settle,
      gap: result.gap,
      vsMedian: result.vsMedian,
    };
    return {
      rounds: rows,
      verdict: verdict,
      sealed: { floor: undefined, cap: undefined },
    };
  }

  return {
    CONCESSION: CONCESSION,
    NATURES: NATURES,
    natureOf: natureOf,
    concessionOf: concessionOf,
    round100: round100,
    settlePrice: settlePrice,
    gapAmount: gapAmount,
    startBids: startBids,
    vsMedianPct: vsMedianPct,
    floorHint: floorHint,
    capIsUnrealistic: capIsUnrealistic,
    neededCap: neededCap,
    bindEvidence: bindEvidence,
    generateRounds: generateRounds,
    publicLog: publicLog,
  };
});
