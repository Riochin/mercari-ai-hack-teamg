import { createRequire } from "node:module";
import assert from "node:assert/strict";

const require = createRequire(import.meta.url);
const P = require("./protocol.js");

const lamp = {
  ask: 5800,
  median: 4800,
  soldCount: 23,
  days: 14,
  viewsTrend: "down",
  condition: "A",
  extras: "付属完備",
  shipping: "送料込み",
};

const phones = {
  ask: 9800,
  median: 8500,
  soldCount: 31,
  days: 3,
  viewsTrend: "stable",
  condition: "A",
  extras: "ケース付",
  shipping: "送料込み",
};

assert.equal(P.round100(5184), 5200);
assert.equal(P.settlePrice(4200, 4800), 4500);
assert.equal(P.settlePrice(8600, 8000), null);
assert.equal(P.gapAmount(8600, 8000), 600);
assert.equal(P.settlePrice(8600, 8600), 8600);

const starts = P.startBids(5800, 4800, 4800);
assert.equal(starts.buyer, 4100);
assert.equal(starts.seller, 5200);

const lampRounds = P.generateRounds(lamp, 4200, 4800);
assert.equal(lampRounds.ok, true);
assert.equal(lampRounds.settle, 4500);
assert.deepEqual(
  lampRounds.rounds.map((r) => r.price),
  [4100, 5200, 4400, 4700, 4500, 4500]
);
assert.deepEqual(
  lampRounds.rounds.map((r) => r.side),
  ["buyer", "seller", "buyer", "seller", "buyer", "seller"]
);
assert.equal(lampRounds.rounds[4].evidence.key, "close");
assert.equal(lampRounds.rounds[5].evidence.key, "close");
assert.equal(lampRounds.vsMedian, -6.3);
assert.equal(lampRounds.rounds[0].evidence.key, "days");
assert.equal(lampRounds.rounds[1].evidence.key, "condition");
assert.equal(lampRounds.rounds[2].evidence.key, "sold");
assert.equal(lampRounds.rounds[3].evidence.key, "shipping");

const gap = P.generateRounds(phones, 8600, 8000);
assert.equal(gap.ok, false);
assert.equal(gap.gap, 600);
assert.deepEqual(
  gap.rounds.map((r) => r.price),
  [7200, 9200, 8000, 8600]
);
assert.deepEqual(
  gap.rounds.map((r) => r.side),
  ["buyer", "seller", "buyer", "seller"]
);

const rescued = P.generateRounds(phones, 8600, P.neededCap(8600));
assert.equal(rescued.ok, true);
assert.equal(rescued.settle, 8600);

assert.equal(P.floorHint(4200, 4800), "high");
assert.equal(P.floorHint(9800, 8500), "low");
assert.equal(P.capIsUnrealistic(3000, 4800), true);
assert.equal(P.capIsUnrealistic(4800, 4800), false);

const log = P.publicLog(lampRounds, { kind: "settled" });
assert.equal("floor" in log.sealed && log.sealed.floor === undefined, true);
assert.equal(log.sealed.cap, undefined);
assert.ok(!JSON.stringify(log).includes("4200"));
assert.ok(!JSON.stringify(log).includes('"cap"'));

const thin = P.generateRounds({ ...lamp, soldCount: 2 }, 4200, 4800);
assert.equal(thin.rounds[2].evidence, null);

assert.equal(P.concessionOf("hardy"), 0.75);
assert.equal(P.concessionOf("adamant"), 0.4);
const stubborn = P.generateRounds(lamp, 4200, 4800, { buyer: "adamant", seller: "adamant" });
assert.equal(stubborn.settle, 4500);
assert.ok(stubborn.rounds.length >= 6);
assert.ok(stubborn.rounds[2].price < 4400);
assert.equal(stubborn.rounds[stubborn.rounds.length - 2].price, 4500);
assert.equal(stubborn.rounds[stubborn.rounds.length - 1].price, 4500);
assert.equal(stubborn.rounds[stubborn.rounds.length - 2].side, "buyer");
assert.equal(stubborn.rounds[stubborn.rounds.length - 1].side, "seller");

console.log("protocol.test.mjs: ok");
