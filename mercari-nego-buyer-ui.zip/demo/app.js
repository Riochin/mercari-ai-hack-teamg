(function () {
  const P = window.NegoProtocol;
  const yen = (n) => "¥" + Number(n).toLocaleString("ja-JP");
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const fast = new URLSearchParams(location.search).has("fast");
  const PACE = reduce ? 80 : fast ? 400 : 5200;

  const ITEMS = {
    lamp: {
      id: "lamp",
      title: "真鍮のデスクランプ 間接照明",
      seller: "さくらの部屋",
      ask: 5800,
      defaultFloor: 4200,
      defaultCap: 4800,
      minBound: 2800,
      median: 4800,
      soldCount: 23,
      days: 14,
      views: 86,
      viewsTrend: "down",
      condition: "A",
      extras: "付属完備",
      shipping: "送料込み",
      category: "インテリア・住まい・小物",
      subcat: "ライト/照明器具",
      conditionJa: "目立った傷や汚れなし",
      region: "東京都",
      shipDays: "1〜2日で発送",
      method: "らくらくメルカリ便",
      likes: 24,
      comments: 3,
      bins: [
        { p: 3200, n: 1 },
        { p: 3600, n: 2 },
        { p: 4000, n: 3 },
        { p: 4400, n: 5 },
        { p: 4800, n: 7 },
        { p: 5200, n: 3 },
        { p: 5600, n: 2 },
      ],
    },
    headphones: {
      id: "headphones",
      title: "ワイヤレスヘッドホン ノイズキャンセリング",
      seller: "おとこの本棚",
      ask: 9800,
      defaultFloor: 8600,
      defaultCap: 8000,
      minBound: 6000,
      median: 8500,
      soldCount: 31,
      days: 3,
      views: 142,
      viewsTrend: "stable",
      condition: "A",
      extras: "ケース・ケーブル付",
      shipping: "送料込み",
      category: "家電・スマホ・カメラ",
      subcat: "オーディオ機器",
      conditionJa: "目立った傷や汚れなし",
      region: "神奈川県",
      shipDays: "1〜2日で発送",
      method: "らくらくメルカリ便",
      likes: 41,
      comments: 5,
      bins: [
        { p: 7200, n: 2 },
        { p: 7600, n: 4 },
        { p: 8000, n: 6 },
        { p: 8500, n: 9 },
        { p: 9000, n: 6 },
        { p: 9400, n: 3 },
        { p: 9800, n: 1 },
      ],
    },
  };

  const state = {
    itemId: "lamp",
    sellerOn: false,
    floor: 4200,
    cap: 4800,
    phase: "idle",
    result: null,
    shown: 0,
    logOpen: false,
    cancelLeft: 300,
    cooldown: false,
    checklist: 0,
    sheet: null,
    timers: [],
    buyerNature: "hardy",
    sellerNature: "hardy",
    sellerArmed: false,
    sellerInbox: null,
    sellerOpenedDeal: false,
  };

  const MON = {
    buyer: { id: "kai", ja: "カイ", role: "買い側" },
    seller: { id: "uri", ja: "ウリ", role: "売り側" },
  };

  function item() {
    return ITEMS[state.itemId];
  }

  function later(fn, ms) {
    const id = setTimeout(fn, ms);
    state.timers.push(id);
    return id;
  }

  function clearTimers() {
    state.timers.forEach(clearTimeout);
    state.timers = [];
    if (state.tick) {
      clearInterval(state.tick);
      state.tick = null;
    }
  }

  function naturePicker(side, current) {
    return `<div class="natures">
      <div class="n-lab">エージェントの性格</div>
      <div class="n-row">${Object.values(P.NATURES)
        .map(
          (n) => `<button type="button" class="n-chip ${current === n.id ? "on" : ""}" data-nature="${n.id}" data-side="${side}">
            <b>${n.ja}</b><small>${n.hint}</small>
          </button>`
        )
        .join("")}</div>
      <p class="priv">いじっぱりほど粘る。成立の中点は性格で変わらない。</p>
    </div>`;
  }

  function bindNatures(root) {
    root.querySelectorAll("[data-nature]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const side = btn.getAttribute("data-side");
        const id = btn.getAttribute("data-nature");
        if (side === "seller") state.sellerNature = id;
        else state.buyerNature = id;
        render();
      });
    });
  }

  function spriteKai() {
    return `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <ellipse cx="32" cy="58" rx="16" ry="4" fill="rgba(0,0,0,.25)"/>
      <path d="M18 22c-6-10 2-16 10-10" fill="#3aa89c"/>
      <path d="M46 22c6-10-2-16-10-10" fill="#3aa89c"/>
      <ellipse cx="32" cy="36" rx="18" ry="16" fill="#5ec8c0"/>
      <ellipse cx="32" cy="40" rx="12" ry="10" fill="#e8fff8"/>
      <circle cx="26" cy="33" r="3" fill="#1a2422"/>
      <circle cx="38" cy="33" r="3" fill="#1a2422"/>
      <circle cx="26.8" cy="32.2" r="1" fill="#fff"/>
      <circle cx="38.8" cy="32.2" r="1" fill="#fff"/>
      <path d="M28 41c2 2 6 2 8 0" fill="none" stroke="#1a2422" stroke-width="1.6" stroke-linecap="round"/>
      <circle cx="16" cy="38" r="4" fill="#f0a04b"/>
    </svg>`;
  }

  function spriteUri() {
    return `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <ellipse cx="32" cy="58" rx="16" ry="4" fill="rgba(0,0,0,.25)"/>
      <ellipse cx="32" cy="34" rx="20" ry="18" fill="#f0a04b"/>
      <ellipse cx="22" cy="20" rx="7" ry="8" fill="#f0a04b"/>
      <ellipse cx="42" cy="20" rx="7" ry="8" fill="#f0a04b"/>
      <ellipse cx="32" cy="38" rx="12" ry="10" fill="#fff3d8"/>
      <circle cx="25" cy="32" r="3.2" fill="#1a2422"/>
      <circle cx="39" cy="32" r="3.2" fill="#1a2422"/>
      <path d="M28 28h8" stroke="#c56a20" stroke-width="2" stroke-linecap="round"/>
      <path d="M29 42c3 2 7 2 10 0" fill="none" stroke="#1a2422" stroke-width="1.6" stroke-linecap="round"/>
      <rect x="40" y="44" width="16" height="10" rx="2" fill="#ff0211"/>
      <path d="M44 49h8" stroke="#fff" stroke-width="1.6"/>
    </svg>`;
  }

  function ico(name) {
    if (name === "back") return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 19l-8-7 8-7"/></svg>`;
    if (name === "share") return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="6" r="2.2"/><circle cx="6" cy="12" r="2.2"/><circle cx="18" cy="18" r="2.2"/><path d="M8 13l8 4M8 11l8-4"/></svg>`;
    if (name === "search") return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/></svg>`;
    if (name === "heart") return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20s-7-4.4-7-10a4 4 0 017-2 4 4 0 017 2c0 5.6-7 10-7 10z"/></svg>`;
    if (name === "comment") return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 17V7a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2H9l-4 3v-3z"/></svg>`;
    return "";
  }

  function listingCard(it) {
    return `<div class="seg">
      <button type="button" class="on">出品中 1</button>
      <button type="button">取引中</button>
      <button type="button">売却済</button>
    </div>
    <div class="listed">
      <div class="th">${art(it)}</div>
      <div>
        <div class="t">${it.title}</div>
        <div class="p">${yen(it.ask)}</div>
        <div class="st"><span class="badge">出品中</span>閲覧 ${it.views} · ♡ ${it.likes}</div>
      </div>
    </div>`;
  }

  function itemChrome(it) {
    const desc = it.id === "headphones"
      ? "使用感少なめ。ケース・ケーブル付属。接続確認済みです。"
      : "点灯確認済み。シェードに薄い使用感あり。デスクに置いて使っていました。";
    return `<div class="ios-bar over"><span>9:41</span><span class="sig">LTE</span></div>
      <div class="hero-wrap">
        <div class="hero">${art(it)}</div>
        <div class="hero-nav">
          <button class="h-ico" type="button" aria-label="戻る">${ico("back")}</button>
          <div class="cluster">
            <button class="h-ico" type="button" aria-label="シェア">${ico("share")}</button>
            <button class="h-ico" type="button" aria-label="検索">${ico("search")}</button>
          </div>
        </div>
        <div class="hero-dots"><i class="on"></i><i></i><i></i></div>
        <div class="hero-count">1/3</div>
      </div>
      <div class="price-block">
        <div class="ask">${yen(it.ask)}</div>
        <div class="ship-line">${it.shipping}（${it.method}）</div>
        <div class="react-row">
          <span>${ico("heart")} ${it.likes}</span>
          <span>${ico("comment")} ${it.comments}</span>
        </div>
      </div>
      <h1 class="item-title">${it.title}</h1>
      <dl class="spec-list">
        <div><dt>カテゴリー</dt><dd>${it.category} ＞ ${it.subcat}</dd></div>
        <div><dt>商品の状態</dt><dd>${it.conditionJa}</dd></div>
        <div><dt>配送料の負担</dt><dd>${it.shipping}</dd></div>
        <div><dt>配送の方法</dt><dd>${it.method}</dd></div>
        <div><dt>発送元の地域</dt><dd>${it.region}</dd></div>
        <div><dt>発送までの日数</dt><dd>${it.shipDays}</dd></div>
      </dl>
      <div class="seller-card">
        <div class="sav" style="background:${it.id === "headphones" ? "#c9b7a4" : "#e8c8b4"}"></div>
        <div>
          <div class="sn">${it.seller}</div>
          <div class="ss">★ 4.9 · 出品 128 · 本人確認済み</div>
        </div>
        <span class="go">›</span>
      </div>
      <div class="desc-block">
        <div class="k">商品の説明</div>
        <p>${desc}<br>出品から${it.days}日 · 閲覧 ${it.views}</p>
      </div>`;
  }

  function art(it) {
    const src = it.id === "headphones" ? "assets/headphones-listing.png" : "assets/lamp-listing.png";
    return `<img src="${src}" alt="${it.title}" width="390" height="390" fetchpriority="high">`;
  }

  function hist(it, floor) {
    const max = Math.max.apply(null, it.bins.map((b) => b.n));
    const bars = it.bins
      .map((b) => {
        const h = Math.max(6, Math.round((b.n / max) * 52));
        const cls = b.p === it.median ? "med" : "";
        return `<b class="${cls}" style="height:${h}px" title="${yen(b.p)}"></b>`;
      })
      .join("");
    return `<div class="hist">
      <div class="hist-bars">${bars}</div>
      <div class="hist-axis"><span>${yen(it.bins[0].p)}</span><span>中央 ${yen(it.median)}</span><span>${yen(it.ask)}</span></div>
    </div>
    <div class="slider-wrap">
      <input id="floor-range" type="range" min="${it.minBound}" max="${it.ask}" step="100" value="${floor}">
    </div>`;
  }

  function hintCopy(level) {
    if (level === "high") return { cls: "high", t: "この下限なら成立しやすい" };
    if (level === "mid") return { cls: "mid", t: "成立は五分五分。少し下げると通りやすい" };
    return { cls: "low", t: "この下限だと成立しにくい（SOLD中央より高い）" };
  }

  function say(side, price, evidence, it) {
    const y = yen(price);
    if (evidence && evidence.key === "close") {
      return side === "buyer" ? `では ${y} でお願いします。` : `了解、${y} で。`;
    }
    if (side === "buyer") {
      if (evidence && evidence.key === "days") {
        return `出品から${it.days}日、閲覧も落ちています。${y}から始めます。`;
      }
      if (evidence && evidence.key === "sold") {
        return `直近${it.soldCount}件の中央値は${yen(it.median)}。${y}まで寄せます。`;
      }
      return `${y}でどうでしょう。`;
    }
    if (evidence && evidence.key === "condition") {
      return `状態${it.condition}、${it.extras}です。${y}が妥当です。`;
    }
    if (evidence && evidence.key === "shipping") {
      return `${it.shipping}でこの水準が下限に近いです。${y}。`;
    }
    return `${y}をお願いします。`;
  }

  function showBanner(who, html) {
    const el = document.getElementById(who + "-banner");
    if (!el) return;
    el.innerHTML = `<div class="push-ico">M</div><div class="push-body">${html}</div>`;
    el.classList.add("on");
    later(() => el.classList.remove("on"), 4200);
  }

  function railPos(price, lo, hi) {
    const t = (price - lo) / (hi - lo || 1);
    return Math.max(8, Math.min(92, t * 84 + 8));
  }

  function renderSeller() {
    const it = item();
    const root = document.getElementById("seller-root");
    if ((state.phase === "settled" || state.phase === "rescued") && state.sellerOpenedDeal) {
      root.innerHTML = `<section class="screen on has-tab">
        ${listingCard(it)}
        ${dealHTML("seller")}
      </section>`;
      const ok = root.querySelector("#ok-deal");
      if (ok) {
        ok.onclick = () => {
          showBanner("seller", "<div class='bt'><b>OK</b><br>この成立で確定します</div>");
        };
      }
      return;
    }
    if (state.phase === "cancelled") {
      root.innerHTML = `<section class="screen on has-tab">
        ${listingCard(it)}
        <div class="inbox fail">
          <div class="notice">
            <div class="n-ico">M</div>
            <div>
              <div class="ih">お知らせ</div>
              <h4>取引がキャンセルされました</h4>
              <p>理由は共有されません。</p>
            </div>
          </div>
        </div>
      </section>`;
      return;
    }
    if (state.phase === "sniped") {
      root.innerHTML = `<section class="screen on has-tab">
        ${listingCard(it)}
        <div class="inbox">
          <div class="notice">
            <div class="n-ico">M</div>
            <div>
              <div class="ih">お知らせ</div>
              <h4>表示価格で売れました</h4>
              <p>表示価格 ${yen(it.ask)} で第三者が購入。交渉より即決が優先です。</p>
            </div>
          </div>
        </div>
      </section>`;
      return;
    }

    const locked = state.sellerArmed || state.phase === "running" || state.sellerInbox;
    const level = P.floorHint(state.floor, it.median);
    const h = hintCopy(level);
    const nat = P.natureOf(state.sellerNature);
    const inbox = sellerInboxHTML();
    const settings = locked
      ? `<div class="nego-panel">
          <div class="nego-top">
            <div>
              <div class="k">${state.sellerOn ? "交渉おまかせ中" : "交渉なし"}</div>
              <div class="s">事前設定。結果は通知で届きます</div>
            </div>
          </div>
          <div class="armed-sum">
            ${state.sellerOn
              ? `ウリの性格は<b>${nat.ja}</b>（${nat.hint}）。下限はセット済み。交渉の途中は見なくて大丈夫です。`
              : "この出品は値下げ交渉を受けません。即決のみです。"}
          </div>
        </div>${inbox}`
      : `<div class="nego-panel">
          <div class="nego-top">
            <div>
              <div class="k">交渉おまかせ</div>
              <div class="s">今だけ決める。あとは通知</div>
            </div>
            <button class="toggle ${state.sellerOn ? "on" : ""}" id="nego-toggle" type="button" aria-label="交渉おまかせ" aria-pressed="${state.sellerOn}"><i></i></button>
          </div>
          <div class="floor-box ${state.sellerOn ? "on" : ""}">
            ${hist(it, state.floor)}
            <div class="floor-read"><span>最低受諾（非公開）</span><span class="v" id="floor-v">${yen(state.floor)}</span></div>
            <div class="hint ${h.cls}" id="floor-hint">${h.t}</div>
            ${naturePicker("seller", state.sellerNature)}
            <p class="priv">下限と性格を先にロックします。成立しても範囲外にはなりません。</p>
            <button class="btn" type="button" id="arm-seller" style="margin-top:12px">この設定で待つ</button>
          </div>
          ${!state.sellerOn ? `<button class="btn ghost" type="button" id="arm-off" style="margin-top:12px">交渉なしで出品する</button>` : ""}
        </div>`;

    root.innerHTML = `
      <section class="screen on has-tab">
        ${listingCard(it)}
        ${settings}
      </section>`;

    const tog = root.querySelector("#nego-toggle");
    if (tog) {
      tog.addEventListener("click", () => {
        state.sellerOn = !state.sellerOn;
        render();
      });
    }
    const range = root.querySelector("#floor-range");
    if (range) {
      range.addEventListener("input", () => {
        state.floor = Number(range.value);
        const lv = P.floorHint(state.floor, it.median);
        const hh = hintCopy(lv);
        root.querySelector("#floor-v").textContent = yen(state.floor);
        const hint = root.querySelector("#floor-hint");
        hint.className = "hint " + hh.cls;
        hint.textContent = hh.t;
      });
    }
    bindNatures(root);
    const arm = root.querySelector("#arm-seller");
    if (arm) arm.onclick = () => { state.sellerOn = true; armSeller(); };
    const armOff = root.querySelector("#arm-off");
    if (armOff) armOff.onclick = () => { state.sellerOn = false; armSeller(); };
    const openAsk = root.querySelector("#open-ask");
    if (openAsk) {
      openAsk.onclick = () => {
        state.sellerOpenedDeal = true;
        render();
      };
    }
  }

  function commentsHTML() {
    return `<div class="comments">
      <div class="c-h">コメント <em>3</em></div>
      <div class="cmt dead">
        <div class="av" style="background:#c9b7a4"></div>
        <div>
          <div><span class="who">購入希望者A</span><span class="when">3日前</span></div>
          <div class="tx">お値下げ可能でしょうか？</div>
        </div>
      </div>
      <div class="cmt dead">
        <div class="av" style="background:#e8c4c4"></div>
        <div>
          <div><span class="who">出品者</span><span class="when">3日前 · 数時間後</span></div>
          <div class="tx">検討します</div>
        </div>
      </div>
      <div class="cmt dead">
        <div class="av" style="background:#c9b7a4"></div>
        <div>
          <div><span class="who">購入希望者A</span><span class="when">1日前</span></div>
          <div class="tx">他で買いました</div>
        </div>
      </div>
    </div>`;
  }

  function buyerDock() {
    return `<div class="nego-rail">
        <button class="btn" id="open-nego" type="button">エージェントで交渉</button>
      </div>
      <div class="dock">
        <button class="dock-ico" type="button">${ico("heart")}いいね</button>
        <button class="dock-ico" type="button">${ico("comment")}コメント</button>
        <button class="btn buy" id="direct-buy" type="button">購入手続きへ</button>
      </div>`;
  }

  function dealHTML(who) {
    const it = item();
    const r = state.result;
    const vs =
      r && r.vsMedian != null
        ? `中央値 ${yen(it.median)} から ${r.vsMedian > 0 ? "+" : ""}${r.vsMedian}%`
        : "";
    const steps = ["メルペイでエスクロー", "匿名配送QRを準備", "相手へ案内を送信"];
    const rows = steps
      .map((s, i) => `<div class="cl-row ${i < state.checklist ? "done" : ""}"><i>✓</i>${s}</div>`)
      .join("");
    const mm = String(Math.floor(state.cancelLeft / 60)).padStart(2, "0");
    const ss = String(state.cancelLeft % 60).padStart(2, "0");
    const sellerAsk =
      who === "seller"
        ? `<button class="btn" type="button" id="ok-deal" style="margin-top:14px">この内容でOK</button>
           <p class="priv">何もしなくても ${mm}:${ss} 後に確定します。範囲外の成立はありません。</p>`
        : "";
    return `<div class="inbox deal-card">
      <div class="ih">成立</div>
      <div class="stamp-mini">成立</div>
      <div class="yen">${yen(r.settle)}</div>
      <div class="vs">${vs}</div>
      <div class="cl">${rows}</div>
      ${sellerAsk}
      <div class="cancel-row">
        <span>取消まで <b id="cd-${who}">${mm}:${ss}</b></span>
        <button type="button" data-cancel="${who}">取り消す</button>
      </div>
    </div>`;
  }

  function buyerNegotiationHTML(mode) {
    const it = item();
    const rounds = (state.result && state.result.rounds) || [];
    const visible = mode === "settled" ? rounds.slice(-2) : rounds.slice(0, state.shown);
    const completed = mode === "settled" ? 4 : mode === "gap" ? 3 : Math.min(3, Math.max(1, Math.ceil(state.shown / 2)));
    const steps = ["相場確認", "提案", "再提案", "確認"]
      .map((label, i) => `<li class="${i < completed ? "done" : i === completed ? "active" : ""}"><i>${i < completed ? "✓" : i + 1}</i><span>${label}</span></li>`)
      .join("");
    const messages = visible.length
      ? visible.map((r) => {
          const who = r.side === "buyer" ? "買い手エージェント" : "売り手エージェント";
          return `<article class="buyer-offer ${r.side}">
            <div class="offer-side" aria-hidden="true">${r.side === "buyer" ? "買" : "売"}</div>
            <div class="offer-main"><div class="offer-who">${who}</div><p>${say(r.side, r.price, r.evidence, it)}</p><strong>${yen(r.price)}</strong></div>
          </article>`;
        }).join("")
      : `<div class="buyer-neg-empty"><span class="pulse-dot"></span><b>相場を確認しています…</b><small>直近のSOLD価格と出品条件を照合中</small></div>`;

    let bottom = "";
    if (mode === "gap") {
      bottom = `<div class="buyer-decision">
        <div class="decision-kicker">購入者の確認待ち</div>
        <h3>あと <em>${yen(state.result.gap)}</em> で成立</h3>
        <p>上限を${yen(state.result.gap)}上げますか？</p>
        <button class="btn" id="raise-cap" type="button">${yen(state.result.gap)}上げて成立</button>
        <button class="decision-link" id="watch-mode" type="button">今回は見送る</button>
      </div>`;
    } else if (mode === "settled") {
      bottom = `<div class="buyer-settled-bar">成立 ${yen(state.result.settle)}</div>
        <div class="buyer-purchase-panel">
          <h3>${yen(state.result.settle)}で購入できます</h3>
          <ul><li><b>¥</b>メルペイで支払い</li><li><b>□</b>匿名配送</li><li><b>○</b>5分以内は取消可能</li></ul>
          <button class="btn" id="buyer-purchase" type="button">購入手続きへ</button>
          <button class="decision-link" id="buyer-log" type="button">交渉ログを見る</button>
        </div>`;
    }

    return `<section class="screen on buyer-nego-screen mode-${mode}">
      <div class="buyer-status"><span>9:41</span><span>LTE</span></div>
      <header class="buyer-neg-header"><button id="buyer-neg-back" type="button" aria-label="商品詳細へ戻る">${ico("back")}</button><h2>価格交渉</h2><span></span></header>
      <div class="buyer-neg-item"><div class="th">${art(it)}</div><div><div class="t">${it.title}</div><div class="p">表示価格 ${yen(it.ask)}</div></div><span>›</span></div>
      <ol class="buyer-progress" aria-label="交渉の進捗">${steps}</ol>
      <div class="buyer-neg-thread" aria-live="polite">${messages}</div>
      ${bottom}
    </section>`;
  }

  function bindBuyerNegotiation(root) {
    const back = root.querySelector("#buyer-neg-back");
    if (back) back.onclick = () => resetTo(state.itemId);
    const raise = root.querySelector("#raise-cap");
    if (raise) raise.onclick = acceptGap;
    const watch = root.querySelector("#watch-mode");
    if (watch) watch.onclick = watchGap;
    const purchase = root.querySelector("#buyer-purchase");
    if (purchase) purchase.onclick = () => showBanner("buyer", "<div class='bt'><b>購入手続きへ</b><br>メルペイの確認に進みます</div>");
    const log = root.querySelector("#buyer-log");
    if (log) log.onclick = () => { state.logOpen = true; render(); };
  }

  function sellerInboxHTML() {
    const nat = P.natureOf(state.sellerNature).ja;
    if (state.sellerInbox === "nego") {
      return `<div class="inbox">
        <div class="notice">
          <div class="n-ico">M</div>
          <div>
            <div class="ih">お知らせ</div>
            <h4>交渉があります</h4>
            <p>ウリ（${nat}）が代わりに交渉中。範囲の外には出ません。結果はあとで届きます。</p>
          </div>
        </div>
      </div>`;
    }
    if (state.sellerInbox === "gap") {
      return `<div class="inbox fail">
        <div class="notice">
          <div class="n-ico">M</div>
          <div>
            <div class="ih">不成立の可能性</div>
            <h4>相手に確認しています</h4>
            <p>いまは成立しません。相手の範囲は見えません。返答が来たら知らせます。</p>
          </div>
        </div>
      </div>`;
    }
    if (state.sellerInbox === "declined") {
      return `<div class="inbox fail">
        <div class="notice">
          <div class="n-ico">M</div>
          <div>
            <div class="ih">決裂</div>
            <h4>不成立。相手が見送りました</h4>
            <p>相場が下がったら1回だけ再通知します。下限は変わっていません。</p>
          </div>
        </div>
      </div>`;
    }
    if (state.sellerInbox === "fail") {
      return `<div class="inbox fail">
        <div class="notice">
          <div class="n-ico">M</div>
          <div>
            <div class="ih">決裂</div>
            <h4>交渉は不成立でした</h4>
            <p>相手の範囲は見えません。</p>
          </div>
        </div>
      </div>`;
    }
    if (state.sellerInbox === "ask" && state.result) {
      const mm = String(Math.floor(state.cancelLeft / 60)).padStart(2, "0");
      const ss = String(state.cancelLeft % 60).padStart(2, "0");
      return `<div class="inbox">
        <div class="notice">
          <div class="n-ico">M</div>
          <div>
            <div class="ih">確認</div>
            <h4>${yen(state.result.settle)} で成立。この内容でOK？</h4>
            <p>事前に決めた下限・性格の内側です。取消は <b id="cd-seller">${mm}:${ss}</b> まで。</p>
            <div class="actions">
              <button class="btn" type="button" id="open-ask">確認する</button>
              <button class="btn ghost" type="button" data-cancel="seller">取り消す</button>
            </div>
          </div>
        </div>
      </div>`;
    }
    return "";
  }

  function armSeller() {
    state.sellerArmed = true;
    state.sellerInbox = null;
    render();
  }

  function renderBuyer() {
    const it = item();
    const root = document.getElementById("buyer-root");
    if (state.phase === "gap") {
      root.innerHTML = buyerNegotiationHTML("gap");
      bindBuyerNegotiation(root);
      return;
    }
    if (state.phase === "watch") {
      root.innerHTML = `<section class="screen on result-screen">
        ${itemChrome(it)}
        <div class="inbox fail">
          <div class="ih">決裂</div>
          <h4>見送りました。相場監視を予約</h4>
          <p>再通知は1回だけ。相手の下限は見えません。</p>
        </div>
      </section>`;
      return;
    }
    if (state.phase === "settled" || state.phase === "rescued") {
      root.innerHTML = buyerNegotiationHTML("settled");
      bindBuyerNegotiation(root);
      return;
    }
    if (state.phase === "cancelled") {
      root.innerHTML = `<section class="screen on result-screen">
        ${itemChrome(it)}
        <div class="inbox fail">
          <div class="ih">お知らせ</div>
          <h4>取引がキャンセルされました</h4>
          <p>理由は共有されません。同じ商品の再交渉は24時間後です。</p>
        </div>
      </section>`;
      return;
    }
    if (state.phase === "sniped") {
      root.innerHTML = `<section class="screen on result-screen">
        ${itemChrome(it)}
        <div class="inbox fail">
          <div class="ih">お知らせ</div>
          <h4>他の人が購入しました</h4>
          <p>交渉は終了。似た出品の監視を提案できます。</p>
          <div class="actions">
            <button class="btn" type="button" id="watch-sim">類似を監視する</button>
          </div>
        </div>
      </section>`;
      const w = root.querySelector("#watch-sim");
      if (w) w.onclick = () => showBanner("buyer", "<div class='bt'><b>監視を開始</b><br>似たヘッドホン／ランプが出たら知らせます</div>");
      return;
    }
    if (state.phase === "running") {
      root.innerHTML = buyerNegotiationHTML("running");
      bindBuyerNegotiation(root);
      return;
    }

    const warn = P.capIsUnrealistic(state.cap, it.median);
    root.innerHTML = `
      <section class="screen on has-dock">
        ${itemChrome(it)}
        ${commentsHTML()}
        ${buyerDock()}
        <button class="shade ${state.sheet === "cap" ? "on" : ""}" id="cap-shade" type="button" aria-label="交渉設定を閉じる"></button>
        <div class="sheet ${state.sheet === "cap" ? "on" : ""}" role="dialog" aria-modal="true" aria-labelledby="nego-sheet-title">
          <div class="grab"></div>
          <h3 id="nego-sheet-title">エージェントで交渉</h3>
          <p class="sub">払える上限だけ決めます。おすすめは相場の中央値 ${yen(it.median)}。出品者には見えません。</p>
          <div class="cap-row"><span>上限 ¥</span><input id="cap-in" name="buyer-cap" aria-label="交渉の上限金額" autocomplete="off" inputmode="numeric" type="number" step="100" min="${it.minBound}" max="${it.ask}" value="${state.cap}"></div>
          <div class="hint ${warn ? "low" : "high"}" id="cap-hint">${warn ? "この上限だと成立しにくい" : "この上限なら十分現実的"}</div>
          ${naturePicker("buyer", state.buyerNature)}
          <button class="btn" id="start-nego" style="margin-top:14px">この範囲で交渉</button>
        </div>
      </section>`;
    root.querySelector("#open-nego").onclick = () => {
      if (state.cooldown) {
        showBanner("buyer", "<div class='bt'>同じ商品の再交渉は24時間に1回です</div>");
        return;
      }
      state.sheet = "cap";
      render();
    };
    const shade = root.querySelector("#cap-shade");
    if (shade) shade.onclick = () => { state.sheet = null; render(); };
    const cin = root.querySelector("#cap-in");
    if (cin) {
      cin.addEventListener("input", () => {
        state.cap = Number(cin.value || 0);
        const w = P.capIsUnrealistic(state.cap, it.median);
        const hint = root.querySelector("#cap-hint");
        hint.className = "hint " + (w ? "low" : "high");
        hint.textContent = w ? "この上限だと成立しにくい" : "この上限なら十分現実的";
      });
    }
    const start = root.querySelector("#start-nego");
    if (start) start.onclick = beginNego;
    const directBuy = root.querySelector("#direct-buy");
    if (directBuy) directBuy.onclick = () => showBanner("buyer", `<div class='bt'><b>${yen(it.ask)}で購入</b><br>購入手続きへ進みます</div>`);
    bindNatures(root);
  }

  function renderLive() {
    const it = item();
    const root = document.getElementById("live-root");
    const bn = P.natureOf(state.buyerNature);
    const sn = P.natureOf(state.sellerNature);
    const rounds = (state.result && state.result.rounds) || [];
    const visible = rounds.slice(0, state.shown);
    const lastB = [...visible].reverse().find((r) => r.side === "buyer");
    const lastS = [...visible].reverse().find((r) => r.side === "seller");
    const settled = state.phase === "settled" || state.phase === "rescued";
    const bidB = settled && state.result ? yen(state.result.settle) : lastB ? yen(lastB.price) : "—";
    const bidS = settled && state.result ? yen(state.result.settle) : lastS ? yen(lastS.price) : "—";

    let sys = "範囲と性格を決めると、エージェントが会話を始めます。";
    if (state.phase === "running") sys = "コメント欄の代わりに、エージェント同士が話しています。";
    if (state.phase === "watch") sys = "決裂。相手が見送りました。相場下落で1回だけ再通知。";
    if (state.phase === "gap") sys = `不成立 · ${yen(state.result.gap)} 差。範囲は非公開のままです。`;
    if (state.phase === "sniped") sys = "即決が先。会話は終了。";
    if (state.phase === "cancelled") sys = "取消。理由は残しません。";
    if (settled) {
      sys = state.logOpen
        ? `公開ログ。範囲は非公開。中点 ${yen(state.result.settle)} で成立。`
        : `では ${yen(state.result.settle)} で成立。範囲の外には出ていません。`;
    }

    const msgs = visible
      .map((r) => {
        const side = r.side === "buyer" ? "buy" : "sell";
        const av = r.side === "buyer" ? spriteKai() : spriteUri();
        const ev = r.evidence ? r.evidence.title : "範囲のみ";
        return `<div class="msg ${side}">
          <div class="av">${av}</div>
          <div class="bal">
            <div class="tag">${ev}</div>
            <div class="tx">${say(r.side, r.price, r.evidence, it)}</div>
            <span class="pr">${yen(r.price)}</span>
          </div>
        </div>`;
      })
      .join("");

    const failed = state.phase === "gap" || state.phase === "watch";
    const showBar = settled || failed || state.phase === "sniped" || state.phase === "cancelled";
    let bar = "";
    if (settled) bar = `<div class="verdict">成立 ${yen(state.result.settle)}<small>中点 · 範囲は非公開</small></div>`;
    else if (state.phase === "gap") bar = `<div class="verdict fail">不成立 ${yen(state.result.gap)} 差<small>相手の範囲は見えません</small></div>`;
    else if (state.phase === "watch") bar = `<div class="verdict fail">決裂<small>見送り · 相場監視を予約</small></div>`;
    else if (state.phase === "sniped") bar = `<div class="verdict fail">即決が先<small>会話は終了</small></div>`;
    else if (state.phase === "cancelled") bar = `<div class="verdict fail">取消<small>理由は残しません</small></div>`;

    root.innerHTML = `
      <div class="live-col">
        <div class="item-strip">
          <div class="th">${art(it)}</div>
          <div>
            <div class="t">${it.title}</div>
            <div class="p">表示価格 ${yen(it.ask)}</div>
          </div>
        </div>
        <div class="agents">
          <div class="sell">${MON.seller.ja} · ${sn.ja} <b>${bidS}</b></div>
          <div class="buy">${MON.buyer.ja} · ${bn.ja} <b>${bidB}</b></div>
        </div>
        <div class="thread" id="nego-thread">
          <div class="sys">${sys}</div>
          ${msgs}
          ${
            state.logOpen && state.result && state.result.settle
              ? `<div class="sys"><b>${yen(state.result.settle)}</b> · 中点 · 範囲は非公開</div>`
              : ""
          }
        </div>
        ${showBar ? bar : ""}
        <div class="composer"><div class="box">メッセージはエージェントが入力します</div></div>
      </div>`;
    const thread = root.querySelector("#nego-thread");
    if (thread) thread.scrollTop = thread.scrollHeight;
  }

  function render() {
    renderSeller();
    renderBuyer();
    renderLive();
    document.querySelectorAll("[data-cancel]").forEach((b) => {
      b.onclick = cancelDeal;
    });
    const dot = document.getElementById("seller-dot");
    if (dot) dot.classList.toggle("on", Boolean(state.sellerInbox));
  }

  function beginNego() {
    if (!state.sellerOn) {
      showBanner("buyer", "<div class='bt'>この出品は交渉オフです。即決のみ</div>");
      return;
    }
    if (!state.sellerArmed) state.sellerArmed = true;
    state.sheet = null;
    state.sellerOpenedDeal = false;
    const it = item();
    const result = P.generateRounds(it, state.floor, state.cap, {
      buyer: state.buyerNature,
      seller: state.sellerNature,
    });
    state.result = result;
    state.shown = 0;
    state.logOpen = false;
    state.phase = "running";
    state.sellerInbox = "nego";
    showBanner("seller", "<div class='bt'><b>交渉があります</b><br>エージェントが代わりに交渉します</div>");
    render();
    playRounds();
  }

  function playRounds() {
    clearTimers();
    const rounds = state.result.rounds;
    function step(i) {
      if (state.phase !== "running") return;
      state.shown = i + 1;
      renderBuyer();
      renderLive();
      if (i + 1 >= rounds.length) {
        later(state.result.ok ? finishSettle : finishGap, reduce ? 200 : 900);
        return;
      }
      later(() => step(i + 1), PACE);
    }
    step(0);
  }

  function finishGap() {
    if (!state.result || state.result.ok) return;
    state.phase = "gap";
    state.shown = state.result.rounds.length;
    state.sellerInbox = "gap";
    render();
    showBanner("seller", "<div class='bt'><b>差額があります</b><br>購入者の確認を待っています</div>");
  }

  function finishSettle() {
    if (state.phase !== "running" && state.phase !== "rescued") {
      if (state.phase !== "gap") return;
    }
    if (state.phase === "running") state.phase = "settled";
    state.shown = (state.result.rounds || []).length;
    state.cancelLeft = 300;
    state.checklist = 0;
    state.sellerInbox = "ask";
    state.sellerOpenedDeal = false;
    render();
    showBanner("seller", `<div class='bt'><b>成立 ${yen(state.result.settle)}</b><br>この内容でOK？ 確認してください</div>`);
    later(() => {
      state.checklist = 1;
      render();
    }, 700);
    later(() => {
      state.checklist = 2;
      render();
    }, 1400);
    later(() => {
      state.checklist = 3;
      render();
    }, 2100);
    if (state.tick) clearInterval(state.tick);
    state.tick = setInterval(() => {
      if (state.phase !== "settled" && state.phase !== "rescued") return;
      state.cancelLeft = Math.max(0, state.cancelLeft - 1);
      document.querySelectorAll("#cd-seller, #cd-buyer").forEach((el) => {
        const mm = String(Math.floor(state.cancelLeft / 60)).padStart(2, "0");
        const ss = String(state.cancelLeft % 60).padStart(2, "0");
        el.textContent = `${mm}:${ss}`;
      });
    }, 1000);
  }

  function acceptGap() {
    const floor = state.floor;
    state.cap = P.neededCap(floor);
    const settle = P.settlePrice(floor, state.cap);
    const close = { key: "close", label: "成立", title: "中点", body: "成立価格" };
    state.result = {
      ok: true,
      settle: settle,
      gap: 0,
      rounds: [
        { side: "buyer", price: settle, evidence: close },
        { side: "seller", price: settle, evidence: close },
      ],
      vsMedian: P.vsMedianPct(settle, item().median),
    };
    state.phase = "rescued";
    state.shown = 2;
    finishSettle();
  }

  function watchGap() {
    state.phase = "watch";
    state.sellerInbox = "declined";
    showBanner("seller", "<div class='bt'><b>決裂</b><br>相手が見送りました</div>");
    showBanner("buyer", "<div class='bt'><b>決裂</b><br>相場監視を予約しました</div>");
    render();
  }

  function cancelDeal() {
    state.phase = "cancelled";
    state.cooldown = true;
    clearTimers();
    render();
    showBanner("seller", "<div class='bt'>成立が取り消されました</div>");
    showBanner("buyer", "<div class='bt'>成立が取り消されました</div>");
  }

  function snipe() {
    if (state.phase !== "running") {
      showBanner("buyer", "<div class='bt'>交渉中だけスナイプできます</div>");
      return;
    }
    clearTimers();
    state.phase = "sniped";
    render();
    showBanner("buyer", "<div class='bt'><b>即決されました</b><br>交渉を終了します</div>");
    showBanner("seller", `<div class='bt'><b>即決 ${yen(item().ask)}</b></div>`);
  }

  function resetTo(id) {
    clearTimers();
    const it = ITEMS[id];
    state.itemId = id;
    state.sellerOn = false;
    state.floor = it.defaultFloor;
    state.cap = it.defaultCap;
    state.phase = "idle";
    state.result = null;
    state.shown = 0;
    state.logOpen = false;
    state.cancelLeft = 300;
    state.checklist = 0;
    state.sheet = null;
    state.buyerNature = "hardy";
    state.sellerNature = "hardy";
    state.sellerArmed = false;
    state.sellerInbox = null;
    state.sellerOpenedDeal = false;
    render();
  }

  function fit() {
    const w = 420 + 270 + 76;
    const h = 920;
    const s = Math.min((window.innerWidth - 24) / w, (window.innerHeight - 24) / h, 1);
    document.documentElement.style.setProperty("--stage-scale", String(s));
  }

  document.querySelectorAll(".beat").forEach((b) => {
    b.addEventListener("click", () => {
      const act = b.getAttribute("data-act");
      if (act === "hook") {
        resetTo(state.itemId);
        state.sheet = null;
        render();
      } else if (act === "seller") {
        state.sellerOn = true;
        state.sellerArmed = false;
        render();
      } else if (act === "buyer") {
        if (!state.sellerOn) state.sellerOn = true;
        if (!state.sellerArmed) state.sellerArmed = true;
        state.sheet = "cap";
        render();
      } else if (act === "play") {
        state.sellerOn = true;
        state.sellerArmed = true;
        state.sheet = null;
        state.buyerNature = "hardy";
        state.sellerNature = "hardy";
        beginNego();
      } else if (act === "stubborn") {
        resetTo("lamp");
        state.sellerOn = true;
        state.sellerArmed = true;
        state.buyerNature = "adamant";
        state.sellerNature = "adamant";
        state.sheet = null;
        beginNego();
      } else if (act === "headphones") {
        resetTo("headphones");
        state.sellerOn = true;
        state.sellerArmed = true;
        state.sheet = "cap";
        render();
      } else if (act === "gap-lamp") {
        resetTo("lamp");
        state.floor = 4800;
        state.cap = 4600;
        state.sellerOn = true;
        state.sellerArmed = true;
        state.sheet = null;
        beginNego();
      } else if (act === "log") {
        if (!state.result) {
          state.sellerOn = true;
          beginNego();
          later(() => {
            state.logOpen = true;
            render();
          }, PACE * 4 + 1200);
        } else {
          state.logOpen = true;
          if (state.phase === "running") {
            clearTimers();
            state.phase = "settled";
            state.shown = state.result.rounds.length;
            finishSettle();
          }
          render();
        }
      } else if (act === "snipe") {
        if (state.phase !== "running") {
          resetTo("lamp");
          state.sellerOn = true;
          beginNego();
          later(snipe, 900);
        } else snipe();
      } else if (act === "lamp") {
        resetTo("lamp");
      } else if (act === "reset") {
        resetTo("lamp");
        state.cooldown = false;
        render();
      }
    });
  });

  window.addEventListener("resize", fit);
  fit();
  resetTo("lamp");
})();
